<template>
  <ToDo />
</template>

<script setup lang="ts">
import ToDo from "../components/ToDo.vue";
</script>
