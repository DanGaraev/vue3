<template>
  <ToDoItemDetailed />
</template>

<script lang="ts" setup>
import ToDoItemDetailed from "../components/ToDoItemDetailed.vue";
</script>
