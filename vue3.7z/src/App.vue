<script setup lang="ts">
import ToDo from "../src/components/ToDo.vue"
</script>

<template>
  <ToDo />
</template>

<style lang="scss" scoped></style>
