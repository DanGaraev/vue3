<template>
  <div class="flex items-center justify-center">
    <p class="text-[24px]/[28px] text-red-300">
      {{ todoStore.detailedToDo.todo }}
    </p>
  </div>
</template>

<script setup lang="ts">
import { useToDoStore } from "../store/todo-store";

const todoStore = useToDoStore();
</script>
